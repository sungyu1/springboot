package jpabook.jpashop.domain;


public enum Role {
    EMPLOYEE,
    MANAGER,
    CENTER_HEAD
}