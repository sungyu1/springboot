package jpabook.jpashop.domain;

public enum ApprovalStatus {
    PENDING, APPROVED, REJECTED
}
