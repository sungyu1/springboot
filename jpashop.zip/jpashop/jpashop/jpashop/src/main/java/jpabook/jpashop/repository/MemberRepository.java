package jpabook.jpashop.repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jpabook.jpashop.domain.Member;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class MemberRepository {

    private final EntityManager em;

    public void save(Member member){
    em.persist(member);
    }

    public Member findOne(String id){
        return em.find(Member.class, id);
    }

//    회원전체 리스트 보이기
    public List<Member> findAll(){
        return em.createQuery("select m from Member m", Member.class).getResultList();

    }
//
    public List<Member> findByName(String name){
        return em.createQuery("select m from Member m where m.name =:name", Member.class)
                .setParameter("name",name).getResultList();
    }
//   회원 로그인
public Member findByEmailAndPassword(String id, String password) {
    return em.createQuery(
                    "select m from Member m where m.id = :id and m.password = :password", Member.class)
            .setParameter("id", id)
            .setParameter("password", password)
            .getResultStream()
            .findFirst()
            .orElse(null); // 없으면 null 반환
}

}
