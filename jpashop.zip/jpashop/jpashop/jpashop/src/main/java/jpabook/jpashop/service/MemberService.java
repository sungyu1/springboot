package jpabook.jpashop.service;

import jpabook.jpashop.domain.Address;
import jpabook.jpashop.domain.Member;
import jpabook.jpashop.domain.oracle.OracleUser;
import jpabook.jpashop.repository.MemberRepository;
import jpabook.jpashop.repository.oracle.OracleUserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class MemberService {

    private final MemberRepository memberRepository;

    /**
     * 회원가입
     **/
    @Transactional(readOnly = false) //쓰기에는 readOnly= false
    public String join(Member member) {
        validateDuplicateMember(member); // 중복회원 있는지 검증
        memberRepository.save(member);
        return member.getId();
    }

    private void validateDuplicateMember(Member member) {
        // 중복 회원 이있을경우 실행
        List<Member> findMembers = memberRepository.findByName(member.getName());
//       만약 findMembers가
        if (!findMembers.isEmpty()) {
            throw new IllegalStateException("이미 존재하는 회원입니다.");
        }
    }


    //    회원전체조회
    public List<Member> findMembers() {
        return memberRepository.findAll();
    }

    //    회원 1명만 조회
    public Member findOne(String memberId) {
        return memberRepository.findOne(memberId);
    }

    /**
     * 로그인
     */
    @Transactional(readOnly = false)
    public Member login(String email, String password) {
        // 1. 로컬 DB에서 찾기
        Member member = memberRepository.findByEmailAndPassword(email, password);
        if (member != null) return member;

        // 2. Oracle DB 조회 (OracleUser → LocalMember 변환)
        OracleUserRepository oracleUserRepository = null;
        OracleUser oracleUser = oracleUserRepository.findByUserId(email); // 이메일=userid 매핑 가정
        if (oracleUser != null && oracleUser.getUseFlag() == 1) {
            Member newMember = new Member();
            newMember.setEmail(oracleUser.getUserId());
            newMember.setName(oracleUser.getName());
            newMember.setPassword(password); // 패스워드 동기화 방식 고민 필요

            // 기본 주소 세팅 or 빈 객체
            newMember.setAddress(new Address("oracleCity", "oracleStreet"));
            newMember.setSignatureImage(null); // 서명 없음

            memberRepository.save(newMember);
            return newMember;
        }

        throw new IllegalArgumentException("이메일 또는 비밀번호가 일치하지 않습니다.");
    }
}
