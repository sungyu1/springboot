package jpabook.jpashop.controller;

import jakarta.servlet.http.HttpSession;
import jpabook.jpashop.domain.Member;
import jpabook.jpashop.service.MemberService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequiredArgsConstructor
public class LoginController {

    private  final MemberService memberService;


//    로그인 버튼 누르면 로그인 폼으로 이동
    @GetMapping("/members/login")// home.html 에서 로그인 버튼을 누르면 발생하는 함수
    public  String loginForm(Model model){
        model.addAttribute("loginForm", new LoginForm());
        return "members/loginForm";// loginFoem 으로 이동
    }

    @PostMapping("/members/login")
//    로그인
    public String login(@ModelAttribute("loginForm") LoginForm loginForm, HttpSession session, Model model){
        try {
            Member member = memberService.login(loginForm.getId(), loginForm.getPassword());
            session.setAttribute("loginMember", member); // 세션에 로그인 사용자 저장
            return "redirect:/index"; //  index.html로 이동

        } catch (IllegalStateException e) {
            model.addAttribute("loginError", e.getMessage());
            return "members/loginForm";
        }

    }
    @GetMapping("/")
    public String home(){
        return "home";
    }


//    로그아웃
//   @GetMapping("/members/logout")
//   public String logout(HttpSession session){
//        session.invalidate();
//        return "redirect:/";
//    }


}
