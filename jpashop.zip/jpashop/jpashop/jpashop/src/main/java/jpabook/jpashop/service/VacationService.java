package jpabook.jpashop.service;

import jakarta.transaction.Transactional;
import jpabook.jpashop.controller.VacationController;
import jpabook.jpashop.domain.VacationRequest;
import jpabook.jpashop.repository.VacationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class VacationService {

    private final VacationRepository vacationRepository;
    @Transactional
    public void submitVacation(VacationRequest vacationRequest) {
        vacationRepository.save(vacationRequest);  // DB 저장
    }
}
