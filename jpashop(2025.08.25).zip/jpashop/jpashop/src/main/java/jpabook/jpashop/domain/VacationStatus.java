package jpabook.jpashop.domain;

public enum VacationStatus {
    DRAFT, PENDING, APPROVED, REJECTED, CANCELED
}
