package jpabook.jpashop.service;

import jpabook.jpashop.domain.Member;
import jpabook.jpashop.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class MemberService {

    private final MemberRepository memberRepository;

    /**
     * 회원가입
     **/
    @Transactional(readOnly = false) //쓰기에는 readOnly= false
    public  Long join(Member member){
        validateDuplicateMember(member); // 중복회원 있는지 검증
        memberRepository.save(member);
        return member.getId();
    }

    private void validateDuplicateMember(Member member) {
        // 중복 회원 이있을경우 실행
        List<Member> findMembers = memberRepository.findByName(member.getName());
//       만약 findMembers가
        if(!findMembers.isEmpty()){
            throw new IllegalStateException("이미 존재하는 회원입니다.");
        }
    }


//    회원전체조회
        public List<Member> findMembers(){
        return memberRepository.findAll();
        }
//    회원 1명만 조회
    public Member findOne(Long memberId){
        return memberRepository.findOne(memberId);
    }

    /**
     * 로그인
     */
    @Transactional(readOnly = false) //쓰기에는 readOnly= false

public Member login(String email, String password) {
    Member member = memberRepository.findByEmailAndPassword(email, password);
    if (member == null) {
        throw new IllegalArgumentException("이메일 또는 비밀번호가 일치하지 않습니다.");
    }
    System.out.println("로그인성공" + member.getName());
    return member;
}

}
