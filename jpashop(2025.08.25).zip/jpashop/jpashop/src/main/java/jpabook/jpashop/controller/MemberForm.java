package jpabook.jpashop.controller;

import jakarta.validation.constraints.NotEmpty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MemberForm {
//  에러 메세지를 보여 줄려면 @NotEmpty 를 사용 해야 한다.
    @NotEmpty(message = "회원 이름은 필수 입니다.")
    private String name;

    @NotEmpty(message = "이메일을 입력해야 합니다.")
    private String email;

    private String password;
    private String city;
    private String street;
    private String zipcode;
    private String signatureData;
}
