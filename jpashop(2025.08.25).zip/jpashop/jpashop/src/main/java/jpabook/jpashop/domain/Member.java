package jpabook.jpashop.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import jpabook.jpashop.domain.Order;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
public class Member {

    @Id
    @GeneratedValue
    @Column(name = "member_id")
    private  Long id;

    private  String name;

    private String email;

    @Column(name = "password", nullable = false)
    private String password;

    @Embedded
    private Address address;


    @Lob
    @Column(columnDefinition = "TEXT")
    private String signatureImage; // base64 이미지


    @OneToMany(mappedBy = "member") //order에 있는 member참조
    private List<Order> orders = new ArrayList<>();
}
