package jpabook.jpashop.domain;


public enum VacationType {
    ANNUAL, HALF_DAY, SICK, OTHER
}
